// app.js - Midas Edge phone app
let SERVER_URL = localStorage.getItem('me_server_url') || '';
let API_KEY = localStorage.getItem('me_api_key') || '';
let lastLogSeen = 0;
let activeTab = 'home';

// ---------- setup ----------
function showSetup(prefill) {
  document.getElementById('setup').classList.add('show');
  if (prefill) {
    document.getElementById('cfgUrl').value = SERVER_URL;
    document.getElementById('cfgKey').value = API_KEY;
  }
}
function hideSetup() { document.getElementById('setup').classList.remove('show'); }

function saveConfig() {
  const url = document.getElementById('cfgUrl').value.trim().replace(/\/$/, '');
  const key = document.getElementById('cfgKey').value.trim();
  if (!url || !key) { toast('Enter both the server address and the password.'); return; }
  SERVER_URL = url.startsWith('http') ? url : 'https://' + url;
  API_KEY = key;
  localStorage.setItem('me_server_url', SERVER_URL);
  localStorage.setItem('me_api_key', API_KEY);
  hideSetup();
  document.getElementById('connInfo').textContent = SERVER_URL;
  poll(); pollDashboard();
}
function resetConnection() { showSetup(true); }

// ---------- networking ----------
async function api(path, options = {}) {
  const res = await fetch(SERVER_URL + path, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY, ...(options.headers || {}) }
  });
  if (!res.ok) throw new Error('Server error ' + res.status);
  return res.json();
}

async function poll() {
  try {
    const s = await api('/api/status');
    setLive(true);
    render(s);
  } catch (e) { setLive(false); }
}
async function pollDashboard() {
  try {
    const s = await api('/api/status');
    if (s.dashboard) renderDashboard(s.dashboard, s.equitySeries || []);
  } catch (e) { /* keep last known dashboard on a blip */ }
}

function setLive(ok) {
  const pill = document.getElementById('livePill');
  pill.className = 'pill ' + (ok ? 'live' : 'off');
  document.getElementById('liveText').textContent = ok ? 'LIVE' : 'OFFLINE';
  document.getElementById('subLine').textContent = ok ? 'connected' : 'can\u2019t reach server';
}

// ---------- rendering: home ----------
function render(s) {
  document.getElementById('equity').textContent = fmtMoney(s.dashboard ? s.dashboard.equity : null, s);
  const pnl = s.dailyPnLPct ?? 0;
  const chip = document.getElementById('dayPnl');
  chip.textContent = (pnl >= 0 ? '+' : '') + pnl.toFixed(2) + '% today';
  chip.className = 'chip ' + (pnl >= 0 ? 'up' : 'down');
  document.getElementById('balanceLine').textContent = s.dashboard ? ('Balance ' + fmtMoney(s.dashboard.balance, s)) : '';

  document.getElementById('openCount').textContent = `(${s.openTrades ?? 0}/${s.maxTrades ?? 3})`;
  const posEl = document.getElementById('positions');
  if (!s.positions || !s.positions.length) {
    posEl.innerHTML = '<div class="empty">No open trades right now</div>';
  } else {
    posEl.innerHTML = s.positions.map(p => `
      <div class="pos">
        <div><b>${p.symbol}</b><span class="side ${p.direction}">${p.direction}</span></div>
        <div class="muted small">${p.lots} lots &middot; SL ${p.sl} &middot; TP ${p.tp}</div>
      </div>`).join('');
  }

  // control tab
  document.getElementById('botState').textContent = s.tradingEnabled ? 'RUNNING' : 'PAUSED';
  const tb = document.getElementById('toggleBtn');
  tb.textContent = s.tradingEnabled ? 'Pause' : 'Resume';
  tb.className = 'btn ' + (s.tradingEnabled ? 'stop' : 'go');
  const rv = s.riskMultiplier ?? 1;
  document.getElementById('riskSlider').value = rv;
  document.getElementById('riskSliderVal').textContent = rv.toFixed(1);
  document.getElementById('connInfo').textContent = SERVER_URL;

  // activity log -> toasts + trades tab
  if (s.log && s.log.length) {
    const newest = new Date(s.log[0].time).getTime();
    if (lastLogSeen && newest > lastLogSeen) {
      s.log.filter(l => new Date(l.time).getTime() > lastLogSeen).reverse().forEach(l => toast(l.text));
    }
    lastLogSeen = newest;
  }
  document.getElementById('log').innerHTML = (s.log || []).slice(0, 20).map(l =>
    `<div class="logi"><span>${timeAgo(l.time)}</span><span>${escapeHtml(l.text)}</span></div>`
  ).join('') || '<div class="empty">Nothing yet</div>';
}

function fmtMoney(v, s) {
  if (typeof v !== 'number') return '--';
  return '$' + v.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

// ---------- rendering: dashboard (signals, plans, history, equity curve) ----------
function renderDashboard(d, series) {
  const gEl = document.getElementById('gauges');
  gEl.innerHTML = (d.signals || []).map(sig => {
    const cls = sig.dir === 1 ? 'buy' : sig.dir === -1 ? 'sell' : 'wait';
    const pct = Math.max(0, Math.min(100, sig.score)) / 100;
    const C = 2 * Math.PI * 30;
    const word = sig.dir === 1 ? 'BUY' : sig.dir === -1 ? 'SELL' : 'WAIT';
    return `<div class="gauge ${cls}">
      <svg viewBox="0 0 76 76">
        <circle class="track" cx="38" cy="38" r="30"/>
        <circle class="arc" cx="38" cy="38" r="30" stroke-dasharray="${(pct*C).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 38 38)"/>
      </svg>
      <div class="gnum">${sig.score.toFixed(0)}</div>
      <div class="glabel">${sig.label}</div>
      <div class="gword">${word}${sig.mode && sig.mode !== '-' ? ' &middot; ' + sig.mode : ''}</div>
    </div>`;
  }).join('') || '<div class="empty">Waiting for the bot...</div>';

  renderPlans(d.plans || []);
  renderHistory(d.history || []);
  renderSpark(series);
}

function renderPlans(plans) {
  const el = document.getElementById('plans');
  if (!plans.length) { el.innerHTML = '<div class="empty">No big USD events coming up in the plan window</div>'; return; }
  el.innerHTML = plans.map(p => {
    const when = new Date(p.utc);
    const statusWord = ['WATCHING', 'TRADED', '', 'SKIPPED', 'DONE'][p.status] || 'WATCHING';
    const legs = p.legs.map(l => {
      const cls = l.dir === 1 ? 'buy' : l.dir === -1 ? 'sell' : '';
      const word = l.dir === 1 ? 'BUY' : l.dir === -1 ? 'SELL' : 'WAIT';
      return `<span class="leg ${cls}">${l.label} ${word}${l.dir !== 0 ? ' ' + l.score.toFixed(0) : ''}</span>`;
    }).join('');
    return `<div class="plan" data-id="${p.id}" data-t="${when.getTime()}">
      <div class="row2">
        <div><div class="name">${escapeHtml(p.name)}</div><div class="when">${when.toLocaleString([], {weekday:'short', hour:'2-digit', minute:'2-digit', month:'short', day:'numeric'})}</div></div>
        <span class="st s${p.status}">${statusWord}</span>
      </div>
      <div class="cd" data-cd>${p.status === 0 ? '--' : '\u2014'}</div>
      <div class="legs">${legs}</div>
      ${p.note ? `<div class="note">${escapeHtml(p.note)}</div>` : ''}
      ${p.status === 0 ? `
      <div class="sw">
        <span>Trade this event</span>
        <label class="toggle"><input type="checkbox" ${p.skip ? '' : 'checked'} onchange="setPlan(${p.id}, this.checked)"><span></span></label>
      </div>` : ''}
    </div>`;
  }).join('');
  tickCountdowns();
}

function tickCountdowns() {
  document.querySelectorAll('[data-cd]').forEach(el => {
    const plan = el.closest('.plan');
    const t = parseInt(plan.dataset.t, 10);
    const diff = t - Date.now();
    if (diff <= 0) { el.textContent = 'Now'; return; }
    const h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000);
    el.textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
  });
}
setInterval(tickCountdowns, 30000);

function setPlan(id, tradeIt) {
  sendCommand(tradeIt ? 'newson' : 'newsskip', id);
  toast(tradeIt ? 'This event will be traded if the plan holds.' : 'This event will be skipped.');
}

function renderHistory(hist) {
  const el = document.getElementById('history');
  if (!hist.length) { el.innerHTML = '<div class="empty">No closed trades yet</div>'; return; }
  let wins = 0, net = 0;
  hist.forEach(h => { if (h.profit >= 0) wins++; net += h.profit; });
  document.getElementById('winrate').textContent = Math.round(wins / hist.length * 100) + '% win rate';
  document.getElementById('netline').textContent = (net >= 0 ? '+' : '') + '$' + net.toFixed(2) + ' (last ' + hist.length + ')';
  el.innerHTML = hist.map(h => `
    <div class="trade">
      <div><b>${h.symbol}</b><span class="side ${h.side}">${h.side}</span></div>
      <div class="pl ${h.profit >= 0 ? 'up' : 'down'}">${h.profit >= 0 ? '+' : ''}$${h.profit.toFixed(2)}</div>
    </div>`).join('');
}

function renderSpark(series) {
  const box = document.getElementById('spark');
  if (!series || series.length < 2) { box.innerHTML = ''; return; }
  const vals = series.map(p => p.v);
  const min = Math.min(...vals), max = Math.max(...vals), span = (max - min) || 1;
  const w = 300, h = 64;
  const pts = series.map((p, i) => {
    const x = i / (series.length - 1) * w;
    const y = h - ((p.v - min) / span) * (h - 6) - 3;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const up = vals[vals.length - 1] >= vals[0];
  box.innerHTML = `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <polyline points="${pts}" fill="none" stroke="${up ? '#34d399' : '#fb7185'}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

// ---------- controls ----------
async function sendCommand(command, value) {
  try { await api('/api/command', { method: 'POST', body: JSON.stringify({ command, value }) }); setTimeout(poll, 700); }
  catch (e) { toast('Could not reach the server.'); }
}
function toggleBot() {
  const running = document.getElementById('botState').textContent === 'RUNNING';
  sendCommand(running ? 'pause' : 'resume');
}
function confirmCloseAll() { if (confirm('Close ALL open trades right now?')) sendCommand('closeall'); }
function panic() { if (confirm('This closes every open trade AND pauses the bot. Continue?')) { sendCommand('closeall'); sendCommand('pause'); } }

// ---------- toasts ----------
function toast(text) {
  const box = document.getElementById('toasts');
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = text;
  box.appendChild(t);
  setTimeout(() => t.remove(), 6000);
  while (box.children.length > 3) box.removeChild(box.firstChild);
}

// ---------- tabs ----------
document.querySelectorAll('.tabbar button').forEach(btn => {
  btn.addEventListener('click', () => {
    activeTab = btn.dataset.tab;
    document.querySelectorAll('.tabbar button').forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.tab').forEach(s => s.classList.toggle('active', s.id === 'tab-' + activeTab));
  });
});

function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function timeAgo(iso) {
  const sec = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (sec < 60) return sec + 's';
  if (sec < 3600) return Math.floor(sec / 60) + 'm';
  return Math.floor(sec / 3600) + 'h';
}

// ---------- boot ----------
if (SERVER_URL && API_KEY) {
  document.getElementById('connInfo').textContent = SERVER_URL;
  poll(); pollDashboard();
} else {
  showSetup(false);
}
setInterval(() => { if (SERVER_URL && API_KEY) poll(); }, 8000);
setInterval(() => { if (SERVER_URL && API_KEY) pollDashboard(); }, 15000);

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
