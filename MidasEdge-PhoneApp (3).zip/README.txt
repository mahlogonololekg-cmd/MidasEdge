MIDAS EDGE - PHONE APP

All files here go directly into the same GitHub repository, all together,
no folders. Follow the simple steps sent in the chat:

1. Make a free GitHub account and a new empty repository called midas-edge.
2. Upload ALL the files in this folder in ONE go (select all of them at once).
3. Make a free Render account (sign up with GitHub), create a Web Service
   from that repository:
     Build command: npm install
     Start command: npm start
     Environment variable: API_KEY = a password you make up
4. Open the address Render gives you, on your phone, enter that password,
   then Add to Home Screen.
5. In MT5 (on your computer): Tools > Options > Expert Advisors > allow
   WebRequest for that address, and put the address + password into the
   bot's InpServerUrl and InpApiKey settings.
