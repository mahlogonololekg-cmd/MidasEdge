// server/index.js
// Minimal bridge server: the EA POSTs status here and polls for commands;
// the phone app reads status and posts commands. Single shared API key auth
// (fine for personal single-user use — do not expose this key).

const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();

const API_KEY = process.env.API_KEY || 'change-me';
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // serves the phone app files at the same address

// ---- in-memory state (resets if the server restarts — fine for this use case) ----
let state = {
  tradingEnabled: true,
  riskMultiplier: 1.0,
  openTrades: 0,
  maxTrades: 3,
  dailyPnLPct: 0,
  positions: [],       // [{symbol, direction, lots, openPrice, sl, tp, mode, score}]
  lastUpdate: null,
  log: [],             // recent events, newest first, capped at 50
  dashboard: null,     // live signals, news plans and recent trades from the bot
  equitySeries: []     // [{t, v}] one point a minute, for the chart
};

let pendingCommands = []; // FIFO queue the EA drains

function checkAuth(req, res, next) {
  const key = req.header('x-api-key') || req.query.key;
  if (key !== API_KEY) return res.status(401).json({ error: 'unauthorized' });
  next();
}

function pushLog(text) {
  state.log.unshift({ text, time: new Date().toISOString() });
  if (state.log.length > 50) state.log.pop();
}

// ---- EA -> server: push latest status ----
app.post('/api/status', checkAuth, (req, res) => {
  const b = req.body || {};
  state.tradingEnabled = b.tradingEnabled ?? state.tradingEnabled;
  state.riskMultiplier = b.riskMultiplier ?? state.riskMultiplier;
  state.openTrades     = b.openTrades ?? state.openTrades;
  state.maxTrades       = b.maxTrades ?? state.maxTrades;
  state.dailyPnLPct    = b.dailyPnLPct ?? state.dailyPnLPct;
  state.positions       = b.positions ?? state.positions;
  state.lastUpdate      = new Date().toISOString();
  if (b.event) pushLog(b.event);
  res.json({ ok: true });
});

// ---- EA -> server: live signals, news plans, recent trades, equity ----
app.post('/api/dashboard', checkAuth, (req, res) => {
  const b = req.body || {};
  state.dashboard = {
    equity: b.equity, balance: b.balance,
    signals: b.signals || [], plans: b.plans || [], history: b.history || []
  };
  const now = Date.now();
  const last = state.equitySeries[state.equitySeries.length - 1];
  if (typeof b.equity === 'number' && (!last || now - last.t >= 60000)) {
    state.equitySeries.push({ t: now, v: b.equity });
    if (state.equitySeries.length > 300) state.equitySeries.shift();
  }
  res.json({ ok: true });
});

// ---- app -> server: read status ----
app.get('/api/status', checkAuth, (req, res) => {
  res.json(state);
});

// ---- app -> server: queue a command ----
app.post('/api/command', checkAuth, (req, res) => {
  const { command, value } = req.body || {};
  const allowed = ['pause', 'resume', 'risk', 'closeall', 'newsskip', 'newson'];
  if (!allowed.includes(command)) return res.status(400).json({ error: 'unknown command' });
  pendingCommands.push({ command, value, time: new Date().toISOString() });
  pushLog(`Command queued: ${command}${value !== undefined ? ' ' + value : ''}`);
  res.json({ ok: true, queued: pendingCommands.length });
});

// ---- EA -> server: drain pending commands ----
app.get('/api/commands/pending', checkAuth, (req, res) => {
  const cmds = pendingCommands;
  pendingCommands = [];
  res.json({ commands: cmds });
});

app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Bridge server listening on port ${PORT}`));
