// app/sw.js - minimal, just enables "Add to Home Screen" installability.
// No offline caching (this app is always-online by design, since it needs live data).
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', () => self.clients.claim());
self.addEventListener('fetch', () => {}); // pass-through
